package com.example.myapplication;

public class SearchRecyclerViewItem {
    private String title;
    private String x;
    private String y;
    //private String road;

   // public String getRoad() {return road;}

   /* public void setRoad(String road) {
        this.road = road;
    }*/
    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getX() {
        return x;
    }

    public void setX(String x) {
        this.x = x;
    }

    public String getY() {
        return y;
    }

    public void setY(String y) {
        this.y = y;
    }
}
